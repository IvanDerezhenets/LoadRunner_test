Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("smp_25_", 
		"URL=http://192.168.0.117:7676/smp_25_", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("1_begin");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(11);

	web_url("index.php", 
		"URL=http://automationpractice.com/index.php?controller=authentication&back=my-account", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/themes/default-bootstrap/img/footer-bg.png", "Referer=http://automationpractice.com/themes/default-bootstrap/css/global.css", ENDITEM, 
		"Url=/themes/default-bootstrap/font/fontawesome-webfont.woff?v=3.2.1", "Referer=http://automationpractice.com/themes/default-bootstrap/css/global.css", ENDITEM, 
		"Url=/themes/default-bootstrap/img/icon/form-ok.png", "Referer=http://automationpractice.com/themes/default-bootstrap/css/global.css", ENDITEM, 
		"Url=/themes/default-bootstrap/img/jquery/uniform/sprite.png", "Referer=http://automationpractice.com/themes/default-bootstrap/css/autoload/uniform.default.css", ENDITEM, 
		"Url=/themes/default-bootstrap/img/bg_bt.gif", "Referer=http://automationpractice.com/themes/default-bootstrap/css/global.css", ENDITEM, 
		"Url=/themes/default-bootstrap/img/functional-bt-shadow.png", "Referer=http://automationpractice.com/themes/default-bootstrap/css/product_list.css", ENDITEM, 
		"Url=/themes/default-bootstrap/img/price-container-bg.png", "Referer=http://automationpractice.com/themes/default-bootstrap/css/product_list.css", ENDITEM, 
		"Url=/themes/default-bootstrap/img/order-step-a.png", "Referer=http://automationpractice.com/themes/default-bootstrap/css/global.css", ENDITEM, 
		"Url=/themes/default-bootstrap/img/order-step-current.png", "Referer=http://automationpractice.com/themes/default-bootstrap/css/global.css", ENDITEM, 
		LAST);

	lr_end_transaction("1_begin",LR_AUTO);

	lr_start_transaction("2_login");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_header("Origin", 
		"http://automationpractice.com");

	web_submit_data("index.php_2", 
		"Action=http://automationpractice.com/index.php?controller=authentication", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://automationpractice.com/index.php?controller=authentication&back=my-account", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=email", "Value=derejenets@ramler.ru", ENDITEM, 
		"Name=passwd", "Value=123Test", ENDITEM, 
		"Name=back", "Value=my-account", ENDITEM, 
		"Name=SubmitLogin", "Value=", ENDITEM, 
		LAST);

	lr_end_transaction("2_login",LR_AUTO);

	lr_start_transaction("3_choose");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(17);

	web_url("Casual Dresses", 
		"URL=http://automationpractice.com/index.php?id_category=9&controller=category", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://automationpractice.com/index.php?controller=my-account", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/img/c/9-category_default.jpg", "Referer=http://automationpractice.com/index.php?id_category=9&controller=category", ENDITEM, 
		"Url=/js/jquery/ui/themes/base/images/ui-bg_flat_75_ffffff_40x100.png", "Referer=http://automationpractice.com/js/jquery/ui/themes/base/jquery.ui.theme.css", ENDITEM, 
		"Url=/js/jquery/ui/themes/base/images/ui-bg_highlight-soft_75_cccccc_1x100.png", "Referer=http://automationpractice.com/js/jquery/ui/themes/base/jquery.ui.theme.css", ENDITEM, 
		"Url=/js/jquery/ui/themes/base/images/ui-bg_glass_75_e6e6e6_1x400.png", "Referer=http://automationpractice.com/js/jquery/ui/themes/base/jquery.ui.theme.css", ENDITEM, 
		LAST);

	lr_end_transaction("3_choose",LR_AUTO);

	lr_start_transaction("4_cart");

	web_add_header("Origin", 
		"http://automationpractice.com");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_submit_data("index.php_3", 
		"Action=http://automationpractice.com/index.php?rand=1645605813285", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://automationpractice.com/index.php?id_category=9&controller=category", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=controller", "Value=cart", ENDITEM, 
		"Name=add", "Value=1", ENDITEM, 
		"Name=ajax", "Value=true", ENDITEM, 
		"Name=qty", "Value=1", ENDITEM, 
		"Name=id_product", "Value=3", ENDITEM, 
		"Name=token", "Value=702845b18252838dcfe693b22f279bf0", ENDITEM, 
		EXTRARES, 
		"Url=/img/p/8/8-cart_default.jpg", "Referer=http://automationpractice.com/index.php?id_category=9&controller=category", ENDITEM, 
		LAST);

	lr_end_transaction("4_cart",LR_AUTO);

	lr_start_transaction("5_proceed");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(15);

	web_url("index.php_4", 
		"URL=http://automationpractice.com/index.php?controller=order", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://automationpractice.com/index.php?id_category=9&controller=category", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("5_proceed",LR_AUTO);

	lr_start_transaction("6_logout");

	web_url("Sign out", 
		"URL=http://automationpractice.com/index.php?mylogout=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://automationpractice.com/index.php?controller=order", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("6_logout",LR_AUTO);

	return 0;
}